export async function handler(event, context) {
  const VERIFY_TOKEN = "abbybotverify123";

  if (event.httpMethod === "GET") {
    const params = event.queryStringParameters;
    const mode = params["hub.mode"];
    const token = params["hub.verify_token"];
    const challenge = params["hub.challenge"];

    if (mode && token === VERIFY_TOKEN) {
      return {
        statusCode: 200,
        body: challenge,
      };
    } else {
      return {
        statusCode: 403,
        body: "Forbidden",
      };
    }
  }

  if (event.httpMethod === "POST") {
    console.log("📩 IG Webhook:", event.body);
    return {
      statusCode: 200,
      body: "EVENT_RECEIVED",
    };
  }

  return {
    statusCode: 404,
    body: "Not Found",
  };
}